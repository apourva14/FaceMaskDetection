#!/usr/local/anaconda3/Anaconda-Navigator.app/Contents/MacOS/python
from subprocess import call

call(["/usr/local/anaconda3/bin/anaconda-navigator"])
